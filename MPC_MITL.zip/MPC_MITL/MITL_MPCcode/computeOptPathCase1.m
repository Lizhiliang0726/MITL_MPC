function optPath=computeOptPathCase1(currentstate,currentPstate,T,P,H,...
    currentpath,lastPrevPstate,optPath,K,t,k,count,t_index,totalpath)

if P.cost(currentPstate)==inf
    error('Current PA state (%i,%i) has inf energy', currentstate(1),currentstate(2));
end


if ~isempty(currentpath.Ppath)
    currentpath.path=[currentpath.path;currentstate];
    currentpath.Ppath=[currentpath.Ppath,currentPstate];
else
    currentpath.path=currentstate;
    currentpath.Ppath=currentPstate;
end

if length(currentpath.Ppath)>K
    error('Horizon of current path > %i',K);
end


if isempty(find(currentpath.path(1:(end-1),1)==currentstate(1), 1))
    currentpath.rewards=currentpath.rewards+T.rewards(t,currentstate(1));
end



if length(currentpath.Ppath)==K
    V=0;
    for i=1:K
        V=V+P.Ih(1,currentpath.Ppath(i))/5+P.Ih(2,currentpath.Ppath(i));
    end
    currentpath.totalcost=currentpath.rewards-100*V;
    
    if P.cost(currentPstate)<=P.cost(lastPrevPstate) ...
            && optPath.totalcost<=currentpath.totalcost
        optPath=currentpath;
    end
    return
else

    t=t+1;

    if count<2
        for i=1:length(P.clock)
            if t>P.clockvalue(i)
                k=i+1;
            end
        end
    end
    

    if count>=2
        for i=1:length(P.clock)
            if t-t_index>P.clockvalue(i)
                k=i+1;
            end
        end
    end
    
    
    
    
    

    
    for ii=find(P.trans{k}(currentPstate,:))
        if isempty(find(currentpath.Ppath==ii, 1)) && P.cost(ii)~=inf
            nextPstate=ii;
            nextstate=P.S(nextPstate,:);
            optPath=computeOptPathCase1(nextstate,nextPstate,T,P,H,currentpath,lastPrevPstate,optPath,K,t,k,count,t_index,totalpath);
        end
    end
    
    
end

