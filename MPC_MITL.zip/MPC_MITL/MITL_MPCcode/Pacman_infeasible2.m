function [T,N]=Pacman_infeasible2()

N=64;

T.numRow=8;
T.N=N;
T.Q = 1:N;

T.Q0 = 1;
fprintf('Initial state of T is %i\n',T.Q0);


T.nodes=[];
for ii=1:N
    T.nodes=[T.nodes, struct('position',[T.numRow*floor((ii-1)/T.numRow),...
        T.numRow*mod((ii-1),T.numRow)],'atomicProp',[])];
end

for ii=1:N
    switch ii
        case {32,40}
            T.nodes(ii).atomicProp=[T.nodes(ii).atomicProp, 'b'];
        case {64}
            T.nodes(ii).atomicProp=[T.nodes(ii).atomicProp, 'c'];
        case {8,57}
            T.nodes(ii).atomicProp=[T.nodes(ii).atomicProp, 'd'];
        case {2,12,28,37,41,56,60}
            T.nodes(ii).atomicProp=[T.nodes(ii).atomicProp, 'a'];  
    end
end



T.N_p = 4;
T.alphabet = alphabet_set(obtainAlphabet(T.N_p));

T.adj = sparse(N,N);

for ii=1:N    

    ProxDiskR=8;
    for jj=1:N
        if jj~=ii && norm(T.nodes(ii).position-T.nodes(jj).position)<=ProxDiskR
            T.adj(ii,jj)=norm(T.nodes(ii).position-T.nodes(jj).position);
        end
    end
       
       

    if isempty(T.nodes(ii).atomicProp)
        T.obs(ii)=2^T.N_p;
        continue
    end  
    
    ap_obs=[];
    for jj=1:length(T.nodes(ii).atomicProp)
        switch T.nodes(ii).atomicProp(jj)
            case 'a'
                ap_obs=[ap_obs, 4];
            case 'b'
                ap_obs=[ap_obs, 3];
            case 'c'
                ap_obs=[ap_obs, 2];
            case 'd'
                ap_obs=[ap_obs, 1];
            otherwise
                disp(T.nodes(ii).atomicProp);
                error('Atomic Proposition not expected!');
        end
        
        ap_obs=sort(ap_obs);
       
    end

    alph_ind=zeros(1,T.N_p);
    alph_ind(ap_obs)=1;
    T.obs(ii)=bin2dec(char(alph_ind+double('0')));
end

end