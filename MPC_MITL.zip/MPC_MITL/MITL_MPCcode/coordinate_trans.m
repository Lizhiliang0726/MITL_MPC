function pos=coordinate_trans(s)


if mod(s,8)==0
    x=floor(s/8);
    y=8;
else
    x=floor(s/8)+1;
    y=mod(s,8);
end
x_real=0.5*x-0.25;
y_real=0.5*y-0.25;
pos=[x_real,y_real];