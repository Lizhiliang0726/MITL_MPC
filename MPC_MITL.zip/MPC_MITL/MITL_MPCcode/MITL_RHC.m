%% MITL_RHC code
close all
clear all
warning off all
addpath('./LTL_Toolbox','./LTL_MPCcode');



global N;N=1;
global topic;
topic=get_topic(N);
global move;move=[];
global odom;odom=[];
global scan;scan=[];
global reset;reset=[];
global vmsg;
global motive;motive=[];
for i=1:N
    move=[move,rospublisher(topic(i).move,'geometry_msgs/Twist')];
    odom =[odom,rossubscriber(topic(i).pos)];
    scan=[scan,rossubscriber(topic(i).scan)];
    reset=[reset,rospublisher(topic(i).reset)];
end
vmsg=rosmessage(move(1)); 

for i=1:N
    motive=[motive,rossubscriber(topic(i).motive)];
end
disp('get_init finish');


FinalT=50;

K=5;

ProxDiskR=23;


[T,N]=Pacman_infeasible();
[T_exe,N_exe]=Pacman_execution();


B=create_relaxtimebuchi4();
P=time_autom_product(T_exe,B);
disp('Product automoton generated');
disp(P);
tic

disp('Computing Energy for each state of P');
dist=graphallshortestpaths(P.trans{1});
P.FS=P.F;
needToCheck=true;
while needToCheck
    needToCheck=false;
    for currentfs=P.FS
        minDist=inf;
        adjset=find(P.trans{1}(currentfs,:));
        for neighstate=adjset
            minDist=min(minDist,min(dist(neighstate,P.FS)));
        end
        if minDist==inf
            P.FS=setdiff(P.FS,currentfs);
            needToCheck=true;
            break
        end
    end
end

if isempty(P.FS)
    error('No self-reachable accepting states, can not satisfy spec with the Transition System');
end
P.cost=zeros(1,size(P.S,1));
for ii=1:length(P.cost)
    P.cost(ii)=min(dist(ii,P.FS));
end
fprintf('Energy computation completed, took %3.2f seconds\n',toc);


TotalReward=0;


H=23;

reachablestates=[];


t=1;

currentstate=P.S(P.S0,:);
currentPstate=P.S0;
currentword{1}=T.nodes(currentstate(1)).atomicProp;
currenttraj=currentstate;
currentPtraj=currentPstate;

maxRewardOverall=15;
minRewardOverall=3;

T_exe.rewards=sparse(FinalT+K,N);
for ii=1:N
    if ii~=currentstate(1)&& isempty(find(T_exe.nodes(ii).atomicProp=='a', 1))...
            && isempty(find(T_exe.nodes(ii).atomicProp=='b', 1))...
            && isempty(find(T_exe.nodes(ii).atomicProp=='c', 1))...
            && isempty(find(T_exe.nodes(ii).atomicProp=='d', 1))
        distanceToCurrent=norm(T_exe.nodes(ii).position-T_exe.nodes(currentstate(1)).position);
        
        if distanceToCurrent<=H && randi(2,1)~=1
            T_exe.rewards(t,ii)=minRewardOverall+(maxRewardOverall-minRewardOverall)*rand;
        end
    end
end

T.rewards=sparse(FinalT+K,N);
for ii=1:N
    T.rewards(t,ii)=T_exe.rewards(t,ii);
end

for i=1:N
    if i~=currentstate(1) && norm(T_exe.nodes(currentstate(1)).position-T_exe.nodes(i).position)<=ProxDiskR
        if T_exe.obs(i)~=T.obs(i)
            T_exe.nodes(i).atomicProp=T.nodes(i).atomicProp;
            T_exe.obs(i)=T.obs(i);
            
            if  T_exe.nodes(i).atomicProp == 'a'
                for x=1:length(B.clock)
                    for y=1:length(B.S)
                        for z=1:length(P.S)
                            if P.trans{x}((i-1)*B.size+y,z)>0
                                PP.trans{x}((i-1)*B.size+y,z)= P.trans{x}((i-1)*B.size+y,z);
                                P.trans{x}((i-1)*B.size+y,z)=inf;
                            end
                        end
                    end
                end
                for x=1:length(B.clock)
                    for y=1:length(B.S)
                        for z=1:length(P.S)
                            if z~=(i-1)*B.size+y && P.trans{x}(z,(i-1)*B.size+y)>0
                                PP.trans{x}(z,(i-1)*B.size+y)=P.trans{x}(z,(i-1)*B.size+y);
                                P.trans{x}(z,(i-1)*B.size+y)=inf;
                            end
                        end
                    end
                end
                
            end
            if  T_exe.nodes(i).atomicProp ~= 'a'
                for x=1:length(B.clock)
                    for y=1:length(B.S)
                        for z=1:length(P.S)
                            if P.trans{x}((i-1)*B.size+y,z)==inf
                                P.trans{x}((i-1)*B.size+y,z)= PP.trans{x}((i-1)*B.size+y,z);
                            end
                        end
                    end
                end
                
                for x=1:length(B.clock)
                    for y=1:length(B.S)
                        for z=1:length(P.S)
                            if z~=(i-1)*B.size+y && P.trans{x}(z,(i-1)*B.size+y)==inf
                                P.trans{x}(z,(i-1)*B.size+y)=PP.trans{x}(z,(i-1)*B.size+y);
                            end
                        end
                    end
                end
            end
        end
    end
end




screen_size = get(0,'ScreenSize');                  
screenCenter = screen_size(3:4)/2;                  
figure_size = [800 600];                        
limit_left = screen_size(3)/2-figure_size(1)/2;     
limit_down = screen_size(4)/2-figure_size(2)/2;     

Fig_real=figure( 'Position',[limit_left limit_down figure_size(1) figure_size(2)],...
    'Color','w','MenuBar','none','Visible','on',...
    'NumberTitle','off','Name','Pacman');
plotGraphNew(currentstate,T,t,TotalReward);
drawnow
filledPacman(T_exe.nodes(currentstate(1)).position,T_exe.nodes(currentstate(1)).position);
drawnow
saveas(Fig_real, './Plot/fig0.jpg');
close
pacman_Fig = figure('Position',[limit_left limit_down figure_size(1) figure_size(2)],...
    'Color','w','Resize','on','MenuBar','none','Visible','on',...
    'NumberTitle','off','Name','Pacman');
plotGraphNew(currentstate,T_exe,t,TotalReward);
drawnow
filledPacman(T_exe.nodes(currentstate(1)).position,T_exe.nodes(currentstate(1)).position);
prevposition=T_exe.nodes(currentstate(1)).position;
drawnow
pause(0.5)
saveas(pacman_Fig, './Plot/fig1.0.jpg');
close(pacman_Fig)
JJ=[];
RR=[];
totalpath=[];

k=1;
count=0;
flag=0;
t_index=0;
filename='log.txt';
fileID=fopen(filename,'w');


first=[0,0,0];
tic
axis([-8,N+8,-8,N+8]);
axis equal
axis off

p0=[0.25,0.25];

Fig_real=figure( 'Position',[limit_left limit_down figure_size(1) figure_size(2)],...
    'Color','w','MenuBar','none','Visible','on',...
    'NumberTitle','off','Name','Pacman');

while t<FinalT
    
    if t==26
        [T,N]=Pacman_infeasible2();    
        T.rewards=sparse(FinalT+K,N);
    end
    
    if currentstate(2)==B.F
        count=count+1;
        if(mod(count,2)==0)
            currentstate(2)=1;
            currentPstate=length(B.S)*(currentstate(1)-1)+currentstate(2);
            k=1;
            flag=1;
            t_index=t-1;
        else
            flag=0;
        end
        
    else
        flag=0;
        
    end
    
    if P.cost(currentPstate)==inf
        error('Current PA state (%i,%i) has inf energy', currentstate(1),currentstate(2));
    end
    fprintf(fileID,'current time : %d\n', t);
    fprintf(fileID,'current parameter k : %d\n', k);
    fprintf(fileID,'Current state: %i,%i\n',currentstate(1),currentstate(2));
    fprintf(fileID,'Current state violation cost: %i,%i\n',P.Ih(1,currentPstate),P.Ih(2,currentPstate));
    fprintf(fileID,'V(currentstate)=%3.2f\n',P.cost(currentPstate));
    JJ=[JJ,P.cost(currentPstate)];
    fprintf(fileID,'Total Reward=%6.1f\n',TotalReward);
    RR=[RR,TotalReward];
    totalpath=[totalpath;currentstate];
    fprintf(fileID,'total path : %s\n', mat2str(totalpath));

    p.path=[];
    p.Ppath=[];
    p.length=0;
    p.rewards=0;
    p.totalcost=-1000000;
    if t>1
        prevPpath=optPath.Ppath(2:end);
        
    end
    
    optPath=p;

    
    if t==1&&flag==0
        optPath=computeOptPathCase3(currentstate,currentPstate,T_exe,P,H,p,optPath,K,t,k,count,t_index,totalpath);
    elseif P.cost(currentPstate)>0 && isempty(find(P.cost(prevPpath)==0))&&flag==0
        optPath=computeOptPathCase1(currentstate,currentPstate,T_exe,P,H,...
            p,prevPpath(end),optPath,K,t,k,count,t_index,totalpath);
    elseif P.cost(currentPstate)>0 && ~isempty(find(P.cost(prevPpath)==0))&&flag==0
        energy0=find(P.cost(prevPpath)==0);
        optPath=computeOptPathCase2(currentstate,currentPstate,T_exe,P,H,...
            p,energy0(1),optPath,K,t,k,count,t_index,totalpath);
    elseif P.cost(currentPstate)==0&&flag==0
        optPath=computeOptPathCase3(currentstate,currentPstate,T_exe,P,H,p,optPath,K,t,k,count,t_index,totalpath);

    elseif P.cost(currentPstate)>0 &&flag==1
        optPath=computeOptPathCase3(currentstate,currentPstate,T_exe,P,H,p,optPath,K,t,k,count,t_index,totalpath);
    end
    
    fprintf(fileID,'Optimal Path=%s\n',mat2str(optPath.path));
    
    if isempty(optPath.Ppath)
        error('Return no solution');
    end
    

    
    if first(1)==1
        delete(h1);
    else
        first(1)=1;
    end
    
    h1=plotGraphNew2(currentstate,T_exe,t,TotalReward);
    
    if first(2)==1
        delete(h2);
    else
        first(2)=1;
    end
    

    prevposition=T_exe.nodes(currentstate(1)).position;  
    prePathii=optPath.path(1,:);   
    for ii=2:length(optPath.Ppath)
        optPathii=optPath.path(ii,:);
        h2(ii)=plot([T_exe.nodes(prePathii(1)).position(1) T_exe.nodes(optPathii(1)).position(1)], ...
            [T_exe.nodes(prePathii(1)).position(2) T_exe.nodes(optPathii(1)).position(2)],'rp--','LineWidth',1);
        prePathii=optPathii;
    end
    drawnow;
    

    fprintf(fileID,'Implmenting next state %s\n',mat2str(optPath.path(2,:)));
    fprintf(fileID,'-----------------------------------------\n');

    t=t+1;
    

    if count<2
        for i=1:length(P.clock)
            if t>P.clockvalue(i)
                k=i+1;
            end
        end
    end
    

    if count>=2
        for i=1:length(P.clock)
            if t-t_index>P.clockvalue(i)
                k=i+1;
            end
        end
    end
    

    currentstate=optPath.path(2,:);
    currentPstate=optPath.Ppath(2);
    
    

    target=coordinate_trans(currentstate(1));

    posmsg=get_state(odom(1));
    posmsg(1:2)=posmsg(1:2)+p0;
    
    dis=norm(posmsg(1:2)-target);

    goalRadius=0.05;
    try
        motivedata=receive(motive(1),0.5);
        pos=motivedata.Pose.Position;
        x=pos.Z;
        y=pos.X;
    catch
        x=-100;
        y=-100;
    end
    
    realpos=[4-roundn(y,-3),roundn(x,-3)];
    
    if x~=-100
        deltapos=realpos-posmsg(1:2);
        if norm(deltapos)<0.8
            p0=p0+deltapos;
            disp('Position correction');
        end
    end
    
    tic
    while(dis>goalRadius)
        posmsg=get_state(odom(1));
        posmsg(1:2)=posmsg(1:2)+p0;
        
        if first(3)==1
            delete(h3);
        else
            first(3)=1;
        end
        [v, omega] = move_control3(target,posmsg);
        con=[v,omega];
        vmsg.Angular.Z = omega;
        vmsg.Linear.X = v;
        send(move(1),vmsg);
        dis=norm(posmsg(1:2)-target);
        posmsg(1:2)=(posmsg(1:2)-[0.25,0.25])*16;
        h3=filledPacman2(posmsg);
    end
    toc
    disp(['Time for point-to-point navigation',num2str(toc)]);
    stop=0;
    
    vmsg.Angular.Z = 0;
    vmsg.Linear.X = 0;
    send(move(1),vmsg);
    
    

    currenttraj=[currenttraj;currentstate];
    currentPtraj=[currentPtraj,currentPstate];
    

    TotalReward=TotalReward+T.rewards(t-1,currentstate(1));
    

    currentword=[currentword, T.nodes(currentstate(1)).atomicProp];
    

    for ii=1:N
        if ii~=currentstate(1)&& isempty(find(T_exe.nodes(ii).atomicProp=='a', 1))...
                && isempty(find(T_exe.nodes(ii).atomicProp=='b', 1))...
                && isempty(find(T_exe.nodes(ii).atomicProp=='c', 1))...
                && isempty(find(T_exe.nodes(ii).atomicProp=='d', 1))
            distanceToCurrent=norm(T_exe.nodes(ii).position-T_exe.nodes(currentstate(1)).position);
            

            if distanceToCurrent<=H && randi(2,1)~=1

                T_exe.rewards(t,ii)=minRewardOverall+(maxRewardOverall-minRewardOverall)*rand;
            end
        end
    end
    
    for ii=1:N
        T.rewards(t,ii)=T_exe.rewards(t,ii);
    end
    

    for i=1:N
        if i~=currentstate(1) && norm(T_exe.nodes(currentstate(1)).position-T_exe.nodes(i).position)<=ProxDiskR

            if T_exe.obs(i)~=T.obs(i)
                T_exe.nodes(i).atomicProp=T.nodes(i).atomicProp;
                T_exe.obs(i)=T.obs(i);
            end

            for y=1:length(B.S)
                for z=1:length(P.S)
                    if P.trans{x}((i-1)*B.size+y,z)>0
                        PP.trans{x}((i-1)*B.size+y,z)= P.trans{x}((i-1)*B.size+y,z);
                        P.trans{x}((i-1)*B.size+y,z)=inf;
                    end
                end
            end
        end
        for x=1:length(B.clock)
            for y=1:length(B.S)
                for z=1:length(P.S)
                    if z~=(i-1)*B.size+y && P.trans{x}(z,(i-1)*B.size+y)>0
                        PP.trans{x}(z,(i-1)*B.size+y)=P.trans{x}(z,(i-1)*B.size+y);
                        P.trans{x}(z,(i-1)*B.size+y)=inf;
                    end
                end
            end
        end
        

        if  isempty(T_exe.nodes(i).atomicProp)
            for x=1:length(B.clock)
                for y=1:length(B.S)
                    for z=1:length(P.S)
                        if P.trans{x}((i-1)*B.size+y,z)==inf
                            P.trans{x}((i-1)*B.size+y,z)= PP.trans{x}((i-1)*B.size+y,z);
                        end
                    end
                end
            end
            
            for x=1:length(B.clock)
                for y=1:length(B.S)
                    for z=1:length(P.S)
                        if z~=(i-1)*B.size+y && P.trans{x}(z,(i-1)*B.size+y)==inf
                            P.trans{x}(z,(i-1)*B.size+y)=PP.trans{x}(z,(i-1)*B.size+y);
                        end
                    end
                end
            end
            
        end
        
    end
    
    

    disp('update energy function');
    tic
    dist=graphallshortestpaths(P.trans{k});
    P.FS=P.F;
    needToCheck=true;
    while needToCheck
        needToCheck=false;
        for currentfs=P.FS
            minDist=inf;
            adjset=find(P.trans{1}(currentfs,:));
            for neighstate=adjset
                minDist=min(minDist,min(dist(neighstate,P.FS)));
            end
            if minDist==inf
                P.FS=setdiff(P.FS,currentfs);
                needToCheck=true;
                break
            end
        end
    end
    
    if isempty(P.FS)
        error('No self-reachable accepting states, can not satisfy spec with the Transition System');
    end
    P.cost=zeros(1,size(P.S,1));
    for ii=1:length(P.cost)
        P.cost(ii)=min(dist(ii,P.FS));
    end
    fprintf('Energy updating completed, took %3.2f seconds\n',toc);
end

fprintf(fileID,'energy: \t');
for w=1:length(JJ)
    fprintf(fileID,'%d',JJ(w));
    fprintf(fileID,'\t');
end
fprintf(fileID,'\n');
fprintf(fileID,'rewards: \t');
for x=1:length(RR)
    fprintf(fileID,'%3.2f',RR(x));
    fprintf(fileID,'\t');
end

res=figure;
subplot(2,1,1)
plot(JJ,'-o','MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',4);
ylabel('Energy');
subplot(2,1,2)
hold on
plot(RR,'b');
ylabel('Rewards');
xlabel('Iterations');
saveas(res,'./Plot/result.jpg');

