function B = create_relaxtimebuchi4()


clock=2;    
states_no=15;
B.clock=1:clock;
B.S=1:states_no;
B.size=states_no;
B.S0=1;     
B.F=8;      
ap=4;       
B.Ih=[0 0 0 1 0 1 1 0 2 1 1 0 2 1 0;0 1 0 0 1 1 0 0 0 0 1 1 1 1 1];     

sig=1:2^(ap+clock+1);


Alph_s = alphabet_set(obtainAlphabet(ap+clock+1));


B.deadlock=[15]; 


B.clockvalue(1)=16;
B.clockvalue(2)=25;


fid = fopen('relax_TBA.txt');
r = fread(fid, '*char')';
fclose(fid);


B.trans=cell(states_no,states_no);
[S_names s_ind e_ind]=regexp(r, '[\n]state (\S*)|^state (\S*)', 'tokens', 'start', 'end');
S_names=[S_names{:}]; 

for i=1:states_no
    if i~=states_no
        str=r((e_ind(i)+3): (s_ind(i+1)-2));   
    else   
        str=r((e_ind(i)+3): end);
    end

    row=regexp(str,'([^\n\r]*)','tokens');  
    row=[row{:}]; 


    for j=1:length(row)
       
        k=strmatch(row{j}((findstr(row{j},' -> ')+4) : end), S_names, 'exact'); 
k;
       
       if str2num(row{j}(1))==1
            B.trans{i,k}=sig; 
            continue
       end

       
        prop=row{j}(1 : (findstr(row{j},' -> ')-1));                                              
        prop1=prop;
        prop1=prop1((findstr(prop1,'{')+1):(findstr(prop1,'}')-1));
         if ~isempty(prop1)
             prop1=prop;
             prop1=prop1((findstr(prop1,'{')+1):(findstr(prop1,'}')-1));
             AP_N=regexp(prop1,'\d*','Match');
             y=[];
             for m=1:length(AP_N)
                 X=strcat('!p',num2str(str2num(char(AP_N(m)))+1));
                 y=strcat(y,X);
                y=strcat(y,',');
             end
             y(end)=[];
             prop1=replace(y,',',' & ');
             prop=replace(prop,prop(findstr(prop,'{'):findstr(prop,'}')),prop1);
         end
                                                      
         atom_pr=regexp(prop,'([!p]+\d+)','tokens'); 
         atom_pr=[atom_pr{:}];
         labels=sig;  
         for ap=1:length(atom_pr) 
             if isempty(findstr(atom_pr{ap},'!'))   
                labels=intersect(labels, find( cellfun( 'isempty', regexp(Alph_s,atom_pr{ap}) ) == 0 ));   
             else    
                 labels=intersect(labels, find( cellfun( 'isempty', regexp(Alph_s,atom_pr{ap}(2:end)) ) ~= 0 )); 
             end
         end
 
         B.trans{i,k}=union(B.trans{i,k},labels);    
    end
end

end