function set = cartesian_product(varargin)



N=zeros(1,nargin);
for i=1:nargin
    if isempty(varargin{i}) 
        set=[];
        return
    end
    varargin{i}=unique(varargin{i});    
    N(i)=length(varargin{i});   
end

N=[1 N 1];  

set=zeros(prod(N),nargin);  

for i = nargin:-1:1 
    prod_val=prod(N(i+2:length(N)));    
    col=zeros(prod_val*length(varargin{i}), 1); 
    for j=1:length(varargin{i})
       
        col(1+prod_val*(j-1) : prod_val*j)=repmat(varargin{i}(j),prod(N(i+2:length(N))),1);  
    end
    col=repmat(col,prod(N(1:i)),1);   
    set(:,i)=col;
end


