
function Alph_s = alphabet_set(alphabet)


N_p=length(alphabet)-1;
Alph_s=cell(1,2^N_p);

for i=1:(2^N_p-1)   
    s=double(dec2bin(i,N_p))-double('0');   
    s=fliplr(s);
    Alph_s{i}=[alphabet{find(s)}]; 
end
Alph_s{end}=alphabet{end};  
