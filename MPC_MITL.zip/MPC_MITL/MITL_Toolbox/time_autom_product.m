function P = time_autom_product(T,B)




S=cartesian_product(T.Q,B.S);

S0=find(ismember(S(:,1)', T.Q0) & ismember(S(:,2)', B.S0));
F = find(ismember(S(:,2)', B.F));


P.S = S;
P.S0 = S0;
P.F = F;

P.Ih=repmat(B.Ih,1,T.N);   

P.clock=B.clock; 
P.clockvalue=B.clockvalue 
P.deadlock=find(ismember(P.S(:,2)',B.deadlock));


st_no=size(P.S,1); 
P.obs(1,:)=T.obs; 
for j=1:length(B.clock) 
    P.obs(j+1,:)=T.obs+2^(T.N_p+j);
end





tic 
for m=1:length(B.clock)+1
ii = [];
jj = [];
ss = [];
vc=[];   
vd=[];  
    for i=1:st_no 
        
        tr_q=find(T.adj(S(i,1),:)); 
        tr_s=find(~cellfun('isempty',B.trans(S(i,2),:))); 
        if(isempty(tr_s))
            continue;
        end
        
        if(isempty(tr_q))
            continue;
        end

        props = B.trans(S(i,2),tr_s);

        enabled = false(1,length(tr_s));

        for j = 1 : length(tr_s)

            enabled(j) = ismember(P.obs(m,S(i,1)), props{j});
        end

        tr_s = tr_s(enabled);

        if(isempty(tr_s))
            continue;
        end
        
        if(isempty(tr_q))
            continue;
        end

        tr_q_rep = repmat(tr_q, 1, length(tr_s));

        tr_s_rep = tr_s(ones(1,length(tr_q)),:);

        tr_s_rep = tr_s_rep(:)';

        stateMask = ismember(S(:,1), tr_q_rep) & ismember(S(:,2), tr_s_rep);

        targetStates = find(stateMask);

        ii = [ii; i*ones(length(targetStates),1)];

        jj = [jj; targetStates];

        ss = [ss; full(T.adj(S(i,1), S(stateMask, 1)))'];

    end
    for r = 1 : size(jj,1)    
        vc=[vc;P.Ih(1,jj(r,1))];
    end

    for r = 1 : size(jj,1)    
        vd=[vd;P.Ih(2,jj(r,1))];
    end

    ss=ss+vc+5*vd;

    trans{m} = sparse(ii, jj, ss, length(T.Q)*length(B.S), length(T.Q)*length(B.S));

end
fprintf('transitions of product automaton took %3.2f seconds\n',toc);

P.trans=trans;


end 