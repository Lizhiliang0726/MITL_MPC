function alphabet=obtainAlphabet(N_p)


pad_no=num2str(length(num2str(N_p+1)));   

for i=1:N_p
    alphabet{i}=sprintf(['p%0' pad_no 'd'],i);  
end

alphabet{i+1}=sprintf(['p%0' pad_no 'd'],i+1);   
